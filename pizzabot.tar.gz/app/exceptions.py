class PlotDescriptionParsingError(Exception):
    pass


class UnprocessablePlotError(Exception):
    pass
